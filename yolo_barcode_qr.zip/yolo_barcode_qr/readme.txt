To test:
 replace coco128 under yolo under with the coco128 file attached here.
 add the zipped(dataset) folder to colab.

